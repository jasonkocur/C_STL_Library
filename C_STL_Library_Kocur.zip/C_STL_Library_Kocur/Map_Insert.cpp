#include<cassert>
#include<string>
#include<map>

using namespace std;
typedef map<string,int> MapT;
typedef MapT::const_iterator MapIterT;

int main()
{
	MapT amap;
	pair<MapIterT,bool> result = amap.insert(make_pair("Fred", 45));
	assert(result.second == true);
	assert(result.first -> second == 45);
	result = amap.insert(make_pair("Fred", 54));
	assert(result.second == false);
	assert(result.first->second == 45);
}
//Not sure exactly what this is doing
//I think it's inserting something into a Map
//But I don't know what a map is.
