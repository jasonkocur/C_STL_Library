#include<cassert>
#include<iostream>
#include<string>
#include<map>
using namespace std;
int main(int argc, char* argv[])
{
	map<string,string> phone_book;
	phone_book["411"] = "Directory";
	phone_book["911"] = "Emergency";
	phone_book["508-678-2811"] = "BCC";
	if(phone_book.find("411") != phone_book.end())
	{
		phone_book.insert
		(
			make_pair
			(
				string("411"),
				string("Directory")
			)
		);
	}
	assert(phone_book.size() == 3);
	map<string,string>::const_iterator it;
	for(it = phone_book.begin(); it != phone_book.end(); it++)
	{
		cout << " " << it->first << " " << it->second << endl;
	}
	return 0;
}

/*I think it is cool to use maps because each container holds unique pairs
