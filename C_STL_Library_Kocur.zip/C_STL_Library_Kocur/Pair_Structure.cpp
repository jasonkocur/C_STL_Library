#include<iostream>
#include<cassert>
#include<string>
#include<utility>
using namespace std;
int main(int argc, char* argv[])
{
	pair<string,string> strstr;
	strstr.first = "Hello";
	strstr.second = "World";
	
	pair<int, string> intstr;
	intstr.first = 1;
	intstr.second = "one";
	
	pair<string, int> strint("two",2);
	assert(strint.first == "two");
	assert(strint.second == 2);
	
	//This is interesting to me that you can take two elements in a vector and mesh them together
	return 0;
}
