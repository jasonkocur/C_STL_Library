#include<algorithm>

bool less_than_7(int value)
{
	return value < 7
}
vector<int> v1;
int count_less = std::count_if(v1.begin(), v1.end(), less_than_7);

/*
This looks like  a algorithm that counts values less than a certain
number.  Would help if I knew about predicates.
