#include<iostream>
#include<vector>
using namespace std;
int main(int argc, char* argv[])
{
	vector<int> vint(10);
	vint[0] = 10;
	vint[1] = 20;
	vint[2] = 30;
	vint[3] = 40;
	vint[4] = 50;
	vint[5] = 60;
	vint[6] = 70;
	vint[7] = 80;
	vint[8] = 90;
	vint[9] = 100;
	vector<int>::iterator it;
	for(it = vint.begin(); it != vint.end(); ++it)
	{
		cout << " " << *it;
	}
	return 0;
}
