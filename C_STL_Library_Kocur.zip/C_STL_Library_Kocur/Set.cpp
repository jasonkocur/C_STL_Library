#include<cassert>
#include<iostream>
#include<set>

using namespace std;
int main(int argc, char* argv[])
{
	set<int> iset;
	
	iset.insert(11);
	iset.insert(-11);
	iset.insert(55);
	iset.insert(22);
	iset.insert(22);
	if(iset.find(55) != iset.end())
	{
		iset.insert(55);
	}
	assert(iset.size() == 4);
	set<int> :: iterator it;
	for(it = iset.begin(); it != iset.end(); it++)
	{
		cout << " " << *it;
	}
	return 0;
	//I kind of think of these as vectors or arrays just another way of thinking of them.
}
