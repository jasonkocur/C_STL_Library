#include<algorithm>
#include<vector>

using namespace std;
int arr[100];
sort(arr,arr+100);
vector v1;
sort(v1.begin(), v1.end());

/*
This seems like a short and concise way to sort values
I believe I may have used this before if I am not mistaken.
