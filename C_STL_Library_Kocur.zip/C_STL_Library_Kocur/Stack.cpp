#include<iostream>
#include<cassert>
#include<stack>
#include<vector>
using namespace std;

int main(int argc, char* argv[])
{
	stack<int> st;
	st.push(100);
	assert(st.size() == 1);
	assert(st.top() == 100);
	
	st.top() =456;
	assert(st.top() == 456);
	
	st.pop();
	assert(st.empty() == true);
	
    cout << "\n" << endl;
    
    //I will be honest if it wasn't for the comments on the pdf i wouldnt know what is goin on.
	
	return 0;
}
