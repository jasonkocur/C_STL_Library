#include<iostream>
#include<vector>
#include<string>

using namespace std;
int main(int argc, char* argv[])
{
	vector<double> vd;
	vector<int> vi;
	vector<string> vs;
	
	vd.push_back(1.0);
	vd.push_back(2.0);
	vd.push_back(3.0);
	
	for(int i; i<vd.size(); i++)
    {
        cout << vd[i] << " ";
    }
    cout << "\n" << endl;
	
	vi.push_back(4);
	vi.push_back(5);
	vi.push_back(6);
	//not sure why this loop wont display
	for(int j; j<vi.size(); j++)
    {
        cout << vi[j] << " ";
    }
    cout << "\n" << endl;
	
	vs.push_back("seven");
	vs.push_back("eight");
	vs.push_back("nine");
	
	for(int i; i<vs.size(); i++)
    {
        cout << vs[i] << " ";
    }
    cout << "\n" << endl;
	return 0;
}
